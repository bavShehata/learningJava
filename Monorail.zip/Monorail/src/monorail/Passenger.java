package monorail;

import java.util.Scanner;
import java.util.ArrayList; // import the ArrayList class

public class Passenger extends User{
    Scanner input = new Scanner(System.in);

    protected String firstName;
    protected String lastName;
    private ArrayList<Booking> bookings; // Add it to the UML
    
    public Passenger(int ssn, String username, String password, String firstName, String lastName){
        super(ssn, username, password);
        this.firstName = firstName;
        this.lastName = lastName;
        bookings = new ArrayList<Booking>();
    }
    public void addBooking() {
        ArrayList<Route> routes = Monorail.routes;
        int seats, routeNumber, confirm, deptTime,choice;
        Route route;
        // Ask for number of seats
        System.out.println("How many seats do you want to book?");
        seats = input.nextInt();
        // Display all routes and pick one
        System.out.println("Which route are you taking?");
        for(int i  = 0; i < routes.size(); i++){
            System.out.println("(" + i + 1 + ")");
            routes.get(i).displayroute();
        }
        routeNumber = input.nextInt() - 1;
        route = routes.get(routeNumber);
        // Display all departure times of the train with available seats
        System.out.println(
                "Pick the train with the most suitable departure time, please note it takes 5 minutes between each station.");
        for (int i = 0; i < route.train[0].departure_time.size(); i++)
            System.out.println("(" + i + 1 + ") " + route.train[0].departure_time.get(i));
        // Confirm
        choice = input.nextInt() - 1;
        deptTime = route.train[0].departure_time.get(choice);
        System.out.println("Here is the booking info: ");
        System.out.printf("Name: %s %s %n", firstName, lastName);
        System.out.printf("SSn: %s %n", ssn); // Still needed
        System.out.printf("Number of seats: %d %n", seats);
        System.out.printf("Route number: %d %n", route);
        System.out.printf("Train departure time: %s %n", deptTime); // Still needed
        System.out.println("(0) Cancel    (1) Confirm");
        confirm = input.nextInt();
        if (confirm == 1) {
            // Add booking
            // Reserve seats
            bookings.add(new Booking(route, deptTime, seats));
        } else {
            return;
        }
    }

    public void removeBooking() {
        int choice, confirm;
        Booking booking;
        // display booking
        displayBookings();
        System.out.println("Pick the booking that you'd want deleted");
        choice = input.nextInt();
        booking = bookings.get(choice-1);
        System.out.println("Are you sure you want to delete this booking?");
        // confirm
        System.out.println("(0) Cancel    (1) Confirm");
        confirm = input.nextInt();
        if (confirm == 1) {
            // remove booking
            // unreserve seats
            bookings.remove(choice-1);
        } else {
            return;
        }

    }

    public void editBooking() {
        int booking, confirm, done, option, change;
        Booking myBooking;
        // Display all bookings
        displayBookings();
        System.out.println("Pick the booking that you'd want to edit");
        booking = input.nextInt();
        myBooking = bookings.get(booking);
        do {
            // Picking a field to edit
            myBooking.displayBooking();
            System.out.println("What would you like to edit?");
            System.out.printf("1 - Number of seats. %n");
            System.out.printf("2 - Train departure time. %n");
            option = input.nextInt();
            switch (option) {
                case 1:
                    // Ask for the new number of seats
                    System.out.println("New number of seats: ");
                    change = input.nextInt();
                    // If new number is less
                    if (change < myBooking.tickets.size()) {
                        // Remove tickets
                        // Unreserve seat(s)
                        for (int i = 0; i < myBooking.tickets.size() - change; i++)
                            myBooking.tickets.remove(i);
                        System.out.println("Number of seats changed successfully ");

                    } else {
                        // If new number is more
                        // Check whether available or not
                        for (int i = 0; i < change - myBooking.tickets.size(); i++)
                            // Add tickets
                            // Reserve seats
                           myBooking.tickets.add(i);
                        System.out.println("Number of seats changed successfully ");
                    }
                    break;
                case 2:
                    // Display available train departure times
                    System.out.println("New departure time: ");
                    for (int i = 0; i < myBooking.route.train[0].departure_time.size(); i++)
                       System.out.println("(" + i + ") " + myBooking.route.train[0].departure_time.get(i));
                    change = input.nextInt();
                    // Update Booking
                    // unreserve seats in old booking
                    // reserver seats in new booking
                    myBooking.departureTime = myBooking.route.train[0].departure_time.get(change);
                    System.out.println("Departure time changed successfully ");
                    break;
            }
            System.out.println("Would you like to edit anything else?");
            System.out.println("(1) Yes    (2) No");
            done = input.nextInt();
        } while (done != 1);
        // display final info
        System.out.println("Here is the new ticket info: ");
        System.out.printf("Name: %s %s %n", firstName, lastName);
        System.out.printf("SSn: %s %n", ssn);
        System.out.printf("Number of seats: %s %n", myBooking.tickets.size());
        System.out.printf("Train departure time: %s %n%n", myBooking.departureTime);
    }
    public Booking displayBookings(){
        // Show bookings Route and departure time
        // 1- Route 1 :  6:30pm
        // Pick booking to view all details 
        
    }
}
